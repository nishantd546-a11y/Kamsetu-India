KAAMSETU INDIA — वेबसाइट फाइल्स

फाइल:
- index.html : पूर्ण मोबाइल-फ्रेंडली वेबसाइट. EMI कॅल्क्युलेटर, कमाई कॅल्क्युलेटर आणि Resume मसुदा टूल कार्यरत आहेत.

प्रकाशित करण्यापूर्वी:
1. पानाच्या शेवटच्या भागात YOUR-EMAIL@example.com हा नमुना ईमेल तुमच्या संपर्क ईमेलने बदला.
2. सर्व मजकूर आणि बाह्य अधिकृत लिंक तपासा.
3. वेबसाइट मोफत प्रकाशित करा. सोपा मार्ग: GitHub Pages.
   - github.com वर खाते तयार करा / sign in करा.
   - नवीन public repository तयार करा (उदा. kaamsetu-india).
   - Add file > Upload files मधून index.html अपलोड करून commit करा.
   - Repository Settings > Pages मध्ये Deploy from a branch निवडा.
   - Branch: main आणि folder: /(root) निवडून Save करा.
   - GitHub दाखवेल ती प्रकाशित URL वापरा. प्रकाशित होण्यासाठी काही मिनिटे लागू शकतात.
4. iPhone वर GitHub ची साइट desktop mode मध्ये वापरावी लागू शकते.

महत्त्वाचे:
- ही static website आहे; login, database, job listing management, contact form submission किंवा AI API जोडलेले नाहीत.
- Google AdSense/Affiliate कमाईसाठी स्वतंत्र पात्रता, मंजुरी आणि disclosure आवश्यक असू शकतात.
- कोणत्याही नोकरी किंवा कमाईची हमी दिलेली नाही.
